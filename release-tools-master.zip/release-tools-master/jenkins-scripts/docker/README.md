This directory contains all the job migrated from pbuilder to docker

Note: the SCRIPT_DIR variable, when used by the jobs in this directory, 
      points to jenkins-scripts/docker instead of just jenkins-script.
