export APT_INSTALL="sudo DEBIAN_FRONTEND=noninteractive apt-get install -y"
