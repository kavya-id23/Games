#!/bin/bash -x

# Knowing Script dir beware of symlink
[[ -L ${0} ]] && SCRIPT_DIR=$(readlink ${0}) || SCRIPT_DIR=${0}
SCRIPT_DIR="${SCRIPT_DIR%/*}"
export GPU_SUPPORT_NEEDED=true

. ${SCRIPT_DIR}/lib/gazebo_ros_pkgs-check-release.bash
