# Description
Dinosaur Run Game developed using Python and PyGame Library.

# Screenshots

![layer 2](https://user-images.githubusercontent.com/68677462/127871816-0b057cb0-88fa-4cf3-8eb1-84d0358c1305.png)
![layer 3](https://user-images.githubusercontent.com/68677462/127871825-92916bf5-6415-4dc8-a22f-d742e502645f.png)
![Layer 1](https://user-images.githubusercontent.com/68677462/127871835-acc90341-18b7-4bdb-a101-06d77406b24a.png)
