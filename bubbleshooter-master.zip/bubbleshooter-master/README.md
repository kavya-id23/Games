Bubbleshooter
=============

![screenshot](https://raw.github.com/justinmeister/bubbleshooter/master/bubble_shooter_screenshot.png)

A bubble shooter made with pygame.  The arrow is controlled by the arrow keys.  Bubbles pop if three or more match up 
using floodfill.  

Music by: Steven O'Brien - 

'Short Upbeat Piece for Guitar in D major', 
'Utopian Theme', 
'Goofy Theme'
https://soundcloud.com/stevenobrien/short-upbeat-piece-for-guitar

https://soundcloud.com/stevenobrien/utopian-theme-2010

https://soundcloud.com/stevenobrien/goofy-theme-2010
